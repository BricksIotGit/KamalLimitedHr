class Images {
  Images._();

  static const String company_logo = "assets/images/company_logo.png";
  static const String header_grey = "assets/images/header_grey.png";
  static const String notification_ic = "assets/images/notification_ic.png";
  static const String search_ic = "assets/images/search_ic.png";
  static const String employ_ic = "assets/images/employ_ic.png";
  static const String profile_ic = "assets/images/profile_ic.png";
  static const String back_arrow_ic = "assets/images/back_arrow.png";
  static const String header_other_screens = "assets/images/header_other_screens.png";
  static const String attachment_ic = "assets/images/attachment_ic.png";
  static const String leave_request_ic = "assets/images/leave_request_ic.png";
  static const String request_approval_ic = "assets/images/request_approval_ic.png";
  static const String summary_ic = "assets/images/summary_ic.png";
  static const String department_status_ic = "assets/images/department_status_ic.png";
  static const String setting_ic = "assets/images/setting_ic.png";
  static const String complainNsuggestion_ic = "assets/images/complainNsuggestion_ic.png";
  static const String signOut_ic = "assets/images/signOut_ic.png";
  static const String mark_attendance = "assets/images/mark_attendance_ic.png";

}
