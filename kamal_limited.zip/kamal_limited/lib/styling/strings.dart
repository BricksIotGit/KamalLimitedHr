

class Strings {
  Strings._();
  static const String log_in="Log in";
  static const String about_us="About us";

}
