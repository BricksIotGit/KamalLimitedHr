package com.example.kamal_limited

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
